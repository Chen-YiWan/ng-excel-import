// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  nitro: {
    preset: 'node-server'
  },
  runtimeConfig: {
    public: {
      backendUrl: process.env.NUXT_PUBLIC_BACKEND_URL || 'http://localhost:4000'
    }
  },
  devServer: {
    port: 3000
  },
  app: {
    head: {
      titleTemplate: (titleChunk) => titleChunk ? `${titleChunk}` : '網站'
    }
  }
})
