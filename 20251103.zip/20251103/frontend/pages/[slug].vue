<script setup>
const route = useRoute()
const config = useRuntimeConfig()
const slug = route.params.slug

const { data: page, error } = await useFetch(`${config.public.backendUrl}/api/pages/${slug}`, { key: `page-${slug}` })
if (error.value) {
  throw createError({ statusCode: 404, statusMessage: '頁面不存在' })
}

useHead(() => {
  const seo = page.value.seo || {}
  const meta = [
    { name: 'description', content: seo.description || '' },
  ]
  if (seo.ogImage) meta.push({ property: 'og:image', content: seo.ogImage })
  if (Array.isArray(seo.meta)) {
    for (const m of seo.meta) {
      if (m?.kind === 'property') meta.push({ property: m.key, content: m.content })
      else meta.push({ name: m.key, content: m.content })
    }
  }
  return {
    title: seo.title || page.value.title || String(slug),
    meta
  }
})
</script>

<template>
  <main style="font-family: system-ui; padding: 24px">
    <component
      v-for="(b,i) in page.content.blocks"
      :key="i"
      :is="resolve(b.type)"
      v-bind="b.props"
    />
  </main>
</template>

<script>
import { h } from 'vue'
const Hero = (props) => h('section', { style: 'padding:48px;border-radius:16px;background:#eef5ff;margin-bottom:16px' }, [
  h('h1', { style: 'margin:0 0 8px 0' }, props.heading || 'Hero 標題'),
  h('p', { style: 'margin:0;color:#444' }, props.sub || '副標文字')
])
const RichText = (props) => h('div', { innerHTML: props.html || '' })

export default {
  methods: {
    resolve(type) {
      if (type === 'hero') return Hero
      if (type === 'text') return RichText
      return (p) => h('div', {}, '未知元件：' + type)
    }
  }
}
</script>
