<template><NuxtPage /></template>
