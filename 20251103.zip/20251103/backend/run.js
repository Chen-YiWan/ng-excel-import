import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import bodyParser from "body-parser";
import { nanoid } from "nanoid";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 4000;
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

app.use(cors());
app.use(bodyParser.json({ limit: "2mb" }));

function ensureDB() {
  if (!fs.existsSync(DB_FILE)) {
    const initial = { pages: [], blocks: [] };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
  }
}

function readDB() {
  ensureDB();
  return JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
}

function writeDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// --- Pages CRUD (content + SEO/meta) ---
// Page shape: { id, slug, title, seo: {title, description, ogImage, meta:[{name,content},{property,content}]}, content: { blocks: [...] } }

app.get("/api/pages", (req, res) => {
  const db = readDB();
  res.json(db.pages);
});

app.get("/api/pages/:slug", (req, res) => {
  const db = readDB();
  const p = db.pages.find((x) => x.slug === req.params.slug);
  if (!p) return res.status(404).json({ error: "Not found" });
  res.json(p);
});

app.post("/api/pages", (req, res) => {
  const db = readDB();
  const { slug, title, seo, content } = req.body || {};
  if (!slug) return res.status(400).json({ error: "slug is required" });
  if (db.pages.some((p) => p.slug === slug)) {
    return res.status(409).json({ error: "slug exists" });
  }
  const page = {
    id: nanoid(10),
    slug,
    title: title || slug,
    seo: seo || {},
    content: content || { blocks: [] },
  };
  db.pages.push(page);
  writeDB(db);
  res.status(201).json(page);
});

app.put("/api/pages/:slug", (req, res) => {
  const db = readDB();
  const idx = db.pages.findIndex((x) => x.slug === req.params.slug);
  if (idx === -1) return res.status(404).json({ error: "Not found" });
  const page = db.pages[idx];
  const { title, seo, content, slug } = req.body || {};
  if (slug && slug !== page.slug) {
    if (db.pages.some((p) => p.slug === slug))
      return res.status(409).json({ error: "new slug exists" });
    page.slug = slug;
  }
  if (title !== undefined) page.title = title;
  if (seo !== undefined) page.seo = seo;
  if (content !== undefined) page.content = content;
  db.pages[idx] = page;
  writeDB(db);
  res.json(page);
});

app.delete("/api/pages/:slug", (req, res) => {
  const db = readDB();
  const before = db.pages.length;
  db.pages = db.pages.filter((x) => x.slug !== req.params.slug);
  if (db.pages.length === before)
    return res.status(404).json({ error: "Not found" });
  writeDB(db);
  res.json({ ok: true });
});

// --- Optional: reusable block presets (for palette) ---
app.get("/api/blocks", (req, res) => {
  const db = readDB();
  res.json(db.blocks || []);
});
app.post("/api/blocks", (req, res) => {
  const db = readDB();
  const b = { id: nanoid(8), ...req.body };
  db.blocks = db.blocks || [];
  db.blocks.push(b);
  writeDB(db);
  res.status(201).json(b);
});

// seed a demo page if DB is empty
ensureDB();
const dbNow = readDB();
if ((dbNow.pages || []).length === 0) {
  dbNow.pages.push({
    id: nanoid(10),
    slug: "home",
    title: "首頁",
    seo: {
      title: "我的網站首頁",
      description: "這是用後台設定的描述",
      ogImage: "",
    },
    content: {
      blocks: [
        {
          type: "hero",
          props: {
            heading: "歡迎來到我的網站",
            sub: "這是拖拉出來的 Hero 區塊",
          },
        },
        {
          type: "text",
          props: { html: "<p>你可以在後台調整區塊排序與內容。</p>" },
        },
      ],
    },
  });
  writeDB(dbNow);
}

app.listen(PORT, () => {
  console.log("API listening on http://localhost:" + PORT);
});
