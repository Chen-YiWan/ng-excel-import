<template>
  <div style="width:280px">
    <h3>元件庫</h3>
    <div v-for="p in presets" :key="p.id" style="border:1px dashed #aaa;padding:8px;margin:6px 0;border-radius:8px">
      <div><b>{{ p.type }}</b></div>
      <small>拖曳或點擊加入</small>
      <div style="margin-top:6px;display:flex;gap:6px">
        <button @click="$emit('add', { type: p.type, props: p.props })">加入</button>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
defineProps<{ presets:any[] }>()
defineEmits(['add'])
</script>
