<template>
  <div style="flex:1">
    <h3>畫布</h3>
    <draggable v-model="localBlocks" item-key="i" handle=".handle" style="min-height:200px;border:1px solid #eee;padding:8px;border-radius:8px">
      <template #item="{ element, index }">
        <div style="border:1px solid #ddd;padding:8px;border-radius:8px;margin:8px 0;background:#fafafa">
          <div class="handle" style="cursor:grab">☰ 拖曳</div>
          <div style="display:flex;gap:8px;align-items:center">
            <label>type:</label>
            <select v-model="element.type">
              <option value="hero">hero</option>
              <option value="text">text</option>
            </select>
            <button @click="remove(index)">刪除</button>
          </div>
          <div v-if="element.type==='hero'" style="margin-top:8px">
            <label>主標題</label>
            <input v-model="element.props.heading" />
            <label style="margin-left:8px">副標</label>
            <input v-model="element.props.sub" />
          </div>
          <div v-else-if="element.type==='text'" style="margin-top:8px">
            <label>HTML</label>
            <textarea v-model="element.props.html" rows="4" style="width:100%"></textarea>
          </div>
        </div>
      </template>
    </draggable>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
// @ts-ignore
import draggable from 'vuedraggable'

const props = defineProps<{ blocks: any[] }>()
const emit = defineEmits(['update:blocks'])

const localBlocks = ref<any[]>(props.blocks || [])

watch(localBlocks, (v) => emit('update:blocks', v), { deep: true })
watch(() => props.blocks, (v) => { localBlocks.value = v || [] }, { deep: true })

function remove(i:number) {
  localBlocks.value.splice(i,1)
}
</script>

<style>
label { font-size: 12px; color:#555; margin-right:6px; }
input, select, textarea { padding:6px 8px; border:1px solid #ccc; border-radius:6px; }
</style>
