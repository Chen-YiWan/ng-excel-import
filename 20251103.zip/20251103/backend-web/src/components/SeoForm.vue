<template>
  <div>
    <h3>SEO / Meta</h3>
    <div>
      <div>
        <label>標題（title）</label><br />
        <input v-model="model.title" style="width: 100%" />
      </div>
      <div>
        <label>描述（description）</label><br />
        <textarea
          v-model="model.description"
          rows="3"
          style="width: 100%"
        ></textarea>
      </div>
      <div>
        <label>OG Image</label><br />
        <input
          v-model="model.ogImage"
          style="width: 100%"
          placeholder="https://..."
        />
      </div>
      <div>
        <label>其他 Meta</label>
        <div
          v-for="(m, i) in model.meta"
          :key="i"
          style="display: flex; gap: 6px; margin: 6px 0"
        >
          <select v-model="m.kind">
            <option value="name">name</option>
            <option value="property">property</option>
          </select>
          <input v-model="m.key" placeholder="keywords 或 og:type" />
          <input v-model="m.content" placeholder="內容" style="flex: 1" />
          <button @click="remove(i)">刪</button>
        </div>
        <button @click="add()">新增一筆 meta</button>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { reactive, watch } from "vue";
const props = defineProps<{ modelValue: any }>();
const emit = defineEmits(["update:modelValue"]);
const model = reactive(
  props.modelValue || { title: "", description: "", ogImage: "", meta: [] }
);
watch(model, () => emit("update:modelValue", model), { deep: true });
function add() {
  model.meta = model.meta || [];
  model.meta.push({ kind: "name", key: "", content: "" });
}
function remove(i: number) {
  model.meta.splice(i, 1);
}
</script>
