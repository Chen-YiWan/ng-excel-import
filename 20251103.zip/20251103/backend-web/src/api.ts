const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:4000'

export async function listPages() {
  const r = await fetch(`${BACKEND_URL}/api/pages`)
  return r.json()
}
export async function getPage(slug) {
  const r = await fetch(`${BACKEND_URL}/api/pages/${slug}`)
  if (!r.ok) throw new Error('Not found')
  return r.json()
}
export async function createPage(payload) {
  const r = await fetch(`${BACKEND_URL}/api/pages`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)})
  if (!r.ok) throw new Error(await r.text())
  return r.json()
}
export async function savePage(slug, payload) {
  const r = await fetch(`${BACKEND_URL}/api/pages/${slug}`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)})
  if (!r.ok) throw new Error(await r.text())
  return r.json()
}
export async function listBlockPresets() {
  const r = await fetch(`${BACKEND_URL}/api/blocks`)
  return r.json()
}
