<template>
  <div style="display:flex;gap:16px;padding:16px;font-family:system-ui">
    <section style="width:260px">
      <h2>頁面</h2>
      <ul>
        <li v-for="p in pages" :key="p.id" style="display:flex;justify-content:space-between;align-items:center;margin:4px 0">
          <button @click="open(p.slug)">{{ p.slug }}</button>
        </li>
      </ul>
      <div style="margin-top:12px">
        <input v-model="newSlug" placeholder="新 slug，如 about" />
        <button @click="create()">建立</button>
      </div>
      <hr style="margin:16px 0" />
      <SeoForm v-if="current" v-model="current.seo" />
    </section>

    <section style="flex:1">
      <h2>模板拖拉編輯（{{ current?.slug || '—' }}）</h2>
      <div v-if="current">
        <div style="display:flex;gap:16px">
          <Palette :presets="presets" @add="addBlock" />
          <Canvas v-model:blocks="current.content.blocks" />
        </div>
        <div style="margin-top:16px;display:flex;gap:8px">
          <button @click="save()">儲存</button>
          <a :href="frontendPreviewUrl" target="_blank">前台預覽</a>
        </div>
      </div>
      <div v-else>請先選擇或建立頁面</div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { listPages, createPage, savePage, getPage, listBlockPresets } from './api'
import Palette from './components/Palette.vue'
import Canvas from './components/Canvas.vue'
import SeoForm from './components/SeoForm.vue'

const pages = ref<any[]>([])
const presets = ref<any[]>([])
const current = ref<any|null>(null)
const newSlug = ref('')

const FRONTEND_URL = import.meta.env.VITE_FRONTEND_URL || 'http://localhost:3000'
const frontendPreviewUrl = computed(() => current.value ? `${FRONTEND_URL}/${current.value.slug}` : '#')

onMounted(async () => {
  pages.value = await listPages()
  presets.value = await listBlockPresets()
  if (pages.value[0]) {
    open(pages.value[0].slug)
  }
})

async function open(slug:string) {
  current.value = await getPage(slug)
}
async function create() {
  if (!newSlug.value) return
  current.value = await createPage({ slug: newSlug.value, title: newSlug.value, seo: {}, content: { blocks: [] } })
  pages.value = await listPages()
  newSlug.value = ''
}
function addBlock(b:any) {
  if (!current.value) return
  current.value.content.blocks.push(JSON.parse(JSON.stringify(b)))
}
async function save() {
  if (!current.value) return
  await savePage(current.value.slug, current.value)
  alert('已儲存')
}
</script>

<style>
button { padding: 6px 10px; border-radius: 8px; border: 1px solid #ccc; background:#fff; cursor:pointer; }
input { padding: 6px 8px; border:1px solid #ccc; border-radius:6px; }
</style>
